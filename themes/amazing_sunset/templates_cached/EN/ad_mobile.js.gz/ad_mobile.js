
$(window).load(function(){var e=document.createElement('div');e.id='cCPKhsmpotjM';e.style.display='none';document.body.appendChild(e);});